import { FileUpload } from './file-upload';

describe('FileUpload', () => {
  it('should create an instance', () => {
    expect(new FileUpload()).toBeTruthy();
  });
});
