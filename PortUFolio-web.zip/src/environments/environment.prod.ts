export const environment = {
  firebase: {
    projectId: 'portufolio-2d9d7',
    appId: '1:371348930196:web:07bf0c4b034690452abe81',
    databaseURL: 'https://portufolio-2d9d7-default-rtdb.firebaseio.com',
    storageBucket: 'portufolio-2d9d7.appspot.com',
    locationId: 'us-west3',
    apiKey: 'AIzaSyA4RWNe-vbdahUN77cfOmA_t6P58NnJB2Q',
    authDomain: 'portufolio-2d9d7.firebaseapp.com',
    messagingSenderId: '371348930196',
    measurementId: 'G-VDGZPG7412',
  },
  production: true
};
